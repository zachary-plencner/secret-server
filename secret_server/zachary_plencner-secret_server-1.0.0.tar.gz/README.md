# Ansible Collection - zachary_plencner.secret_server

This collection contains modules for creating and retreiving secrets from Delinea's Secret Server PAM software.
